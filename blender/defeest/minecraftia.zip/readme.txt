﻿The font file in this archive was created by Andrew Tyler www.AndrewTyler.net and font@andrewtyler.net
License: http://creativecommons.org/licenses/by-sa/3.0/us/

Use at 12 or 24 px size with anti-alising off for best results.

Creative Commons BY-SA license.

Not affiliated or endorsed by Mojang in anyway. 


